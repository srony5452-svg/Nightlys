DemoTrade — PostgreSQL Version

This is a DEMO / VIRTUAL-MONEY trading simulation. It is not real-money trading.

Features:
- User signup/login
- Each user has a separate demo balance
- Buy/Sell simulation
- Trade history
- Admin can set demo balances
- PostgreSQL database
- Persistent login sessions via PostgreSQL

Default admin on first database initialization:
Email: admin@example.com
Password: value of ADMIN_PASSWORD environment variable (default: admin123)

IMPORTANT:
Change ADMIN_PASSWORD and SESSION_SECRET before public deployment.
Keep the DEMO / VIRTUAL MONEY label visible. Do not use this app as fake financial proof.

Environment variables:
DATABASE_URL
SESSION_SECRET
ADMIN_PASSWORD
NODE_ENV=production

Start:
npm install
npm start
