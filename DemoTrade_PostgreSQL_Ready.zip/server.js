const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");

const app = express();
const PORT = process.env.PORT || 3000;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});

app.use(express.json());
app.use(session({
  store: new pgSession({ pool, createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || "change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7*24*60*60*1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      balance NUMERIC(20,2) NOT NULL DEFAULT 10000,
      admin BOOLEAN NOT NULL DEFAULT FALSE
    );
    CREATE TABLE IF NOT EXISTS trades (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      side TEXT NOT NULL CHECK(side IN ('buy','sell')),
      amount NUMERIC(20,2) NOT NULL,
      price NUMERIC(20,8) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  const { rows } = await pool.query("SELECT id FROM users WHERE admin=true LIMIT 1");
  if (!rows.length) {
    const password = process.env.ADMIN_PASSWORD || "admin123";
    const hash = await bcrypt.hash(password, 10);
    await pool.query(
      "INSERT INTO users(username,email,password,balance,admin) VALUES($1,$2,$3,$4,true)",
      ["admin", "admin@example.com", hash, 100000]
    );
  }
}

function auth(req,res,next) {
  if (!req.session.uid) return res.status(401).json({error:"Login required"});
  next();
}
async function adminOnly(req,res,next) {
  if (!req.session.uid) return res.status(401).json({error:"Login required"});
  const r = await pool.query("SELECT admin FROM users WHERE id=$1",[req.session.uid]);
  if (!r.rows[0]?.admin) return res.status(403).json({error:"Admin only"});
  next();
}

app.post("/api/register", async (req,res) => {
  try {
    const {username,email,password} = req.body || {};
    if (!username || !email || !password || password.length < 6)
      return res.status(400).json({error:"Username, email and 6+ character password required"});
    const hash = await bcrypt.hash(password,10);
    const r = await pool.query(
      "INSERT INTO users(username,email,password) VALUES($1,$2,$3) RETURNING id",
      [username.trim(), email.trim().toLowerCase(), hash]
    );
    req.session.uid = r.rows[0].id;
    res.json({ok:true});
  } catch(e) { res.status(400).json({error:"Username or email already exists"}); }
});

app.post("/api/login", async (req,res) => {
  const email = String(req.body.email||"").trim().toLowerCase();
  const r = await pool.query("SELECT * FROM users WHERE email=$1",[email]);
  const u = r.rows[0];
  if (!u || !(await bcrypt.compare(String(req.body.password||""),u.password)))
    return res.status(401).json({error:"Invalid login"});
  req.session.uid = u.id;
  res.json({ok:true});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/me",auth,async(req,res)=>{
  const u = (await pool.query("SELECT id,username,email,balance,admin FROM users WHERE id=$1",[req.session.uid])).rows[0];
  const trades = (await pool.query(
    "SELECT side,amount,price,created_at FROM trades WHERE user_id=$1 ORDER BY id DESC LIMIT 50",[u.id]
  )).rows;
  res.json({user:u,trades});
});

app.post("/api/trade",auth,async(req,res)=>{
  const side = req.body.side;
  const amount = Number(req.body.amount);
  const price = Number(req.body.price);
  if (!["buy","sell"].includes(side) || !Number.isFinite(amount) || !Number.isFinite(price) || amount<=0 || price<=0)
    return res.status(400).json({error:"Invalid trade"});
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const u = (await client.query("SELECT balance FROM users WHERE id=$1 FOR UPDATE",[req.session.uid])).rows[0];
    const balance = Number(u.balance);
    const newBalance = side === "buy" ? balance - amount : balance + amount;
    if (side === "buy" && amount > balance) {
      await client.query("ROLLBACK");
      return res.status(400).json({error:"Insufficient demo balance"});
    }
    await client.query("UPDATE users SET balance=$1 WHERE id=$2",[newBalance,req.session.uid]);
    await client.query("INSERT INTO trades(user_id,side,amount,price) VALUES($1,$2,$3,$4)",
      [req.session.uid,side,amount,price]);
    await client.query("COMMIT");
    res.json({ok:true});
  } catch(e) {
    await client.query("ROLLBACK");
    res.status(500).json({error:"Trade failed"});
  } finally { client.release(); }
});

app.get("/api/admin/users",adminOnly,async(req,res)=>{
  const r = await pool.query("SELECT id,username,email,balance,admin FROM users ORDER BY id DESC");
  res.json(r.rows);
});

app.post("/api/admin/balance",adminOnly,async(req,res)=>{
  const id = Number(req.body.userId);
  const balance = Number(req.body.balance);
  if (!Number.isInteger(id) || !Number.isFinite(balance) || balance<0)
    return res.status(400).json({error:"Invalid balance"});
  await pool.query("UPDATE users SET balance=$1 WHERE id=$2",[balance,id]);
  res.json({ok:true});
});

initDb().then(()=>{
  app.listen(PORT,()=>console.log(`DemoTrade running on port ${PORT}`));
}).catch(err=>{
  console.error(err);
  process.exit(1);
});
